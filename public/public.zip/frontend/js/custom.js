; (function ($) {

    "use strict";

    // Go!

});
