<div class="card">
    <div class="card-body">
        <?php echo e($content); ?>

    </div>
</div>
<?php /**PATH F:\laragon\www\almacen\resources\views/vendor/jetstream/components/action-section.blade.php ENDPATH**/ ?>