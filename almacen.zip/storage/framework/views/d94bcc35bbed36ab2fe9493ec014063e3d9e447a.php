<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>DETALLES DE CUENTA</h1>

    <p>
        Querid@ <?php echo e($user->name); ?>.
    </p>

    <p>
        <strong>Usuario: </strong> <?php echo e($user->email); ?>

    </p>
    <p>
        <strong>Contraseña: </strong> <?php echo e($clave); ?>

    </p>

    <p>
        <div>
            <strong>
                <h4>
                    <?php echo e(env('APP_NAME')); ?>

                </h4>
            </strong>
        </div>
    </p>
</body>
</html>
<?php /**PATH F:\laragon\www\almacen\resources\views/emails/UserPassword.blade.php ENDPATH**/ ?>