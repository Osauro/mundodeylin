<div class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="text-right">
                    <button type="button" class="btn btn-default" data-toggle="modal" wire:click="resetUI()" data-target="#theModal">
                        Agregar
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if($devoluciones->count()): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="bg-dark text-white">
                                <th width="200px">Fecha</th>
                                <th>Producto</th>
                                <th class="text-right" width="200px">Cantidad</th>
                                <th class="text-center" width="200px">Estado</th>
                                <th width="10px"></th>
                            </thead>
                            <?php $__currentLoopData = $devoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devolucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($devolucion->created_at); ?></td>
                                <td><?php echo e($devolucion->producto->nombre); ?></td>
                                <td class="text-right"><?php echo e($devolucion->cantidad); ?></td>
                                <td class="text-center"><?php echo e($devolucion->estado); ?></td>
                                <td>
                                    <?php if($devolucion->estado == 'Pendiente'): ?>
                                        <button class="btn btn-sm btn-danger" wire:click="cancelar(<?php echo e($devolucion->id); ?>)"><i class="fa fa-times-circle"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                <?php else: ?>
                    <h3>No se encontrarón resultados...</h3>
                <?php endif; ?>
            </div>
            <?php if($devoluciones->count()): ?>
                <div class="card-footer">
                    <?php echo e($devoluciones->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('livewire.devolucionForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function(){
        window.livewire.on('show-modal', msg => {
            $('#theModal').modal('show');
        });

        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/devoluciones.blade.php ENDPATH**/ ?>