<div class="content">
    <div class="container-fluid">
        <div class="text-right">
            <button type="button" class="btn btn-default" data-toggle="modal" wire:click="resetUI()" data-target="#theModal">
                Agregar
            </button>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="row align-content-between">
                    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <small>
                                        <strong>
                                            DESDE
                                        </strong>
                                    </small>
                                </span>
                                <input type="date" wire:model="desde" class="form-control" autofocus>
                            </div>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <small>
                                        <strong>
                                            HASTA
                                        </strong>
                                    </small>
                                </span>
                                <input type="date" wire:model="hasta" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="bg-dark text-white">
                            <th width="150px">Fecha</th>
                            <th width="150px">Usuario</th>
                            <th width="150px">Detalle</th>
                            <th>Descripción</th>
                            <th width="150px" class="text-right">Ingreso</th>
                            <th width="150px" class="text-right">Egreso</th>
                            <th width="150px" class="text-right">Saldo</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($movimiento->created_at); ?></td>
                                    <td><?php echo e($movimiento->user->name); ?></td>
                                    <td><?php echo e($movimiento->detalle); ?></td>
                                    <td><?php echo e($movimiento->descripcion); ?></td>
                                    <td class="text-right"><?php echo e($movimiento->ingreso); ?></td>
                                    <td class="text-right"><?php echo e($movimiento->egreso); ?></td>
                                    <td class="text-right"><?php echo e($movimiento->saldo); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <?php echo e($movimientos->links()); ?>

            </div>
        </div>
    </div>
    <?php echo $__env->make('livewire.movimientosForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/onscan.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        window.livewire.on('show-modal', msg => {
            $('#theModal').modal('show');
        });

        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });

        window.livewire.on('message-error', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });

        try {
            onScan.attachTo(document, {
                suffixKeyCodes: [13],
                onScan: function(qrcode) { //función callback que se dispara después de una lectura
                    console.log(qrcode)
                    window.livewire.emit('addProducto', qrcode) //emitimos el evento para consultar la info y cobrar el ticket
                },
                onScanError: function(e){ //función callback para captura de errores de lectura
                }
            })
        } catch(e) {
            Swal.fire({
                position: 'top-end',
                icon: 'danger',
                title: e,
                showConfirmButton: false,
                timer: 1500
            })
        }
    })
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/movimientos.blade.php ENDPATH**/ ?>