<div class="content">
    <div class="container-fluid">
        <div class="text-right">
            <button type="button" class="btn btn-default" data-toggle="modal" wire:click="resetUI()" data-target="#theModal">
                Agregar
            </button>
        </div>
        <div class="card">
            <div class="card-header">
                <?php echo $__env->make('commons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="bg-dark text-white">
                            <th width="50px">#</th>
                            <th>Nombre</th>
                            <th width="200px">Slug</th>
                            <th width="100px">Image</th>
                            <th width="10px"></th>
                        </thead>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($categoria->id); ?></td>
                            <td><?php echo e($categoria->nombre); ?></td>
                            <td><?php echo e($categoria->slug); ?></td>
                            <td><img src="<?php echo e(asset('storage') . '/' . $categoria->image); ?>" alt="" width="64" height="64" class="img img-thumbnail"></td>
                            <td>
                                <?php if($categoria->deleted_at): ?>
                                    <button class="btn btn-sm btn-secondary"><i class="fa fa-pen" disabled="disabled"></i></button>
                                    <button class="btn btn-sm btn-warning" wire:click="restore(<?php echo e($categoria->id); ?>)"><i class="fa fa-sync"></i></button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($categoria->id); ?>)"><i class="fa fa-pen"></i></button>
                                    <button class="btn btn-sm btn-danger" wire:click="destroy(<?php echo e($categoria->id); ?>)"><i class="fa fa-times-circle"></i></button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <?php if($categorias->count()): ?>
                <div class="card-footer">
                    <?php echo e($categorias->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('livewire.categoriasForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function(){
        window.livewire.on('show-modal', msg => {
            $('#theModal').modal('show');
        });

        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/categorias.blade.php ENDPATH**/ ?>