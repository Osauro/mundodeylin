<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 mt-3">
        ,<div class="card">
            <div class="card-body">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fa fa-store"></i>
                        </span>
                    </div>
                    <select wire:model="tienda" class="form-control" style="font-size: 20px; padding: 3px">
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-header card-header-success">
                <h4 class="card-title">PEDIDOS</h4>
                <p class="category">Pedidos pendientes.</p>
            </div>
            <div class="card-body mt-3">
                <?php if($pedidos->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <th>Tienda</th>
                                <th>Usuario</th>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Estado</th>
                                <th width="10px"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pedido->tienda->nombre); ?></td>
                                        <td><?php echo e($pedido->user->name); ?></td>
                                        <td><?php echo e($pedido->producto->nombre); ?></td>
                                        <td><?php echo e($pedido->cantidad); ?></td>
                                        <td><?php echo e($pedido->estado); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-success" wire:click="aceptarPedido(<?php echo e($pedido->id); ?>)">
                                                <i class="fa fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" wire:click="cancelarPedido(<?php echo e($pedido->id); ?>)">
                                                <i class="fa fa-times-circle"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <h5>No hay pedidos pendientes.</h5>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-header card-header-danger">
                <h4 class="card-title">DEVOLUCIONES</h4>
                <p class="category">Devoluciones pendientes.</p>
            </div>
            <div class="card-body mt-3">
                <?php if($devoluciones->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <th>Tienda</th>
                                <th>Usuario</th>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Estado</th>
                                <th width="10px"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $devoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devolucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($devolucion->tienda->nombre); ?></td>
                                        <td><?php echo e($devolucion->user->name); ?></td>
                                        <td><?php echo e($devolucion->producto->nombre); ?></td>
                                        <td><?php echo e($devolucion->cantidad); ?></td>
                                        <td><?php echo e($devolucion->estado); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-success" wire:click="aceptarDevolucion(<?php echo e($devolucion->id); ?>)">
                                                <i class="fa fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" wire:click="cancelarDevolucion(<?php echo e($devolucion->id); ?>)">
                                                <i class="fa fa-times-circle"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <h5>No hay devoluciones pendientes.</h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function(){
        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/admin.blade.php ENDPATH**/ ?>