            </div>
            <div class="modal-footer">
                <button wire:click.prevent="resetUI()" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <?php if($selected_id < 1): ?>
                    <button wire:click.prevent="store()" type="button" class="btn btn-default">Guardar</button>
                <?php else: ?>
                    <button wire:click.prevent="update()" type="button" class="btn btn-default">Actualizar</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\laragon\www\almacen\resources\views/commons/modalFooter.blade.php ENDPATH**/ ?>