<div class="row align-content-between">
    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <i class="fa fa-search"></i>
                </span>
            </div>
            <input type="text" wire:model="search" class="form-control" placeholder="Buscar..." autofocus>
        </div>
    </div>
</div>
<?php /**PATH F:\laragon\www\almacen\resources\views/commons/search.blade.php ENDPATH**/ ?>