<div class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <?php echo $__env->make('commons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row align-content-between">
                    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-store"></i>
                                </span>
                            </div>
                            <p class="form-control"><?php echo e($tienda->nombre); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-mobile-alt"></i>
                                </span>
                            </div>
                            <p class="form-control"><?php echo e($tienda->telefono); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if($articulos->count()): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="bg-dark text-white">
                                <th>Nombre</th>
                                <th class="text-center">Codigo</th>
                                <th class="text-center">Codigo QR</th>
                                <th class="text-center">Medida</th>
                                <th class="text-right">Precio/U</th>
                                <th class="text-right">Precio/M</th>
                                <th class="text-center">Imagen</th>
                                <th class="text-right">Stock</th>
                            </thead>
                            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($articulo->nombre); ?></td>
                                <td class="text-center"><?php echo e($articulo->codigo); ?></td>
                                <td class="text-center"><?php echo QrCode::size(100)->generate($articulo->codigo); ?></td>
                                <td class="text-center"><?php echo e($articulo->producto->unidad_medida); ?></td>
                                <td class="text-right"><?php echo e($articulo->producto->precio_unitario); ?></td>
                                <td class="text-right"><?php echo e($articulo->producto->precio_por_mayor); ?></td>
                                <td class="text-center">
                                    <?php if($articulo->producto->image): ?>
                                    <img src="<?php echo e(asset('storage') . '/' . $articulo->producto->image); ?>" alt="" width="100" height="100">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('storage')); ?>/no-image.png" alt="" width="100" height="100">
                                    <?php endif; ?>
                                </td>
                                <td class="text-right"><?php echo e($articulo->cantidad); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                <?php else: ?>
                    <h3>No se encontrarón resultados...</h3>
                <?php endif; ?>
            </div>
            <?php if($articulos->count()): ?>
                <div class="card-footer">
                    <?php echo e($articulos->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/articulos.blade.php ENDPATH**/ ?>