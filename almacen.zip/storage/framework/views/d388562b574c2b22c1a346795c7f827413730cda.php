<div class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="row align-content-between">
                    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <small>
                                        <strong>
                                            DESDE
                                        </strong>
                                    </small>
                                </span>
                                <input type="date" wire:model="desde" class="form-control" autofocus>
                            </div>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <small>
                                        <strong>
                                            HASTA
                                        </strong>
                                    </small>
                                </span>
                                <input type="date" wire:model="hasta" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class="bg-dark text-white">
                            <th width="200px">Fecha</th>
                            <th>Usuario</th>
                            <th>Cliente</th>
                            <th>NIT</th>
                            <th width="150px">Estado</th>
                            <th width="10px"></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($venta->created_at); ?></td>
                                    <td><?php echo e($venta->user->name); ?></td>
                                    <td><?php echo e($venta->cliente->nombre); ?></td>
                                    <td><?php echo e($venta->cliente->nit); ?></td>
                                    <td><?php echo e($venta->estado); ?></td>
                                    <td>
                                        <?php if($venta->estado == "Completado"): ?>
                                        <button class="btn btn-sm btn-success" wire:click="imprimirPDF(<?php echo e($venta->id); ?>)">
                                            <span class="material-icons">
                                                print
                                            </span>
                                        </button>
                                        <?php else: ?>
                                        <button class="btn btn-sm btn-link">
                                            <span class="material-icons">
                                                print
                                            </span>
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <?php echo e($ventas->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/onscan.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        window.livewire.on('show-modal', msg => {
            $('#theModal').modal('show');
        });

        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });

        try {
            onScan.attachTo(document, {
                suffixKeyCodes: [13],
                onScan: function(qrcode) { //función callback que se dispara después de una lectura
                    console.log(qrcode)
                    window.livewire.emit('addProducto', qrcode) //emitimos el evento para consultar la info y cobrar el ticket
                },
                onScanError: function(e){ //función callback para captura de errores de lectura
                }
            })
        } catch(e) {
            Swal.fire({
                position: 'top-end',
                icon: 'danger',
                title: e,
                showConfirmButton: false,
                timer: 1500
            })
        }
    })
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/ventas.blade.php ENDPATH**/ ?>