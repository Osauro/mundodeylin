<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<div class="antialiased">
    <?php echo e($slot); ?>

    <?php echo $__env->yieldPushContent('modals'); ?>
</div>
<?php /**PATH F:\laragon\www\almacen\resources\views/layouts/app.blade.php ENDPATH**/ ?>