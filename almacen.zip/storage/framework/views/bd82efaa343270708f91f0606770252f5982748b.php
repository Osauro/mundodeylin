<div class="content">
    <div class="container-fluid">
        <div class="text-right">
            <button type="button" class="btn btn-default" data-toggle="modal" wire:click="resetUI()" data-target="#theModal">
                Agregar
            </button>
            <button type="button" class="btn btn-default" data-toggle="modal" wire:click="resetUI()" data-target="#theModalMedida">
                <i class="fa fa-balance-scale"></i>
            </button>
        </div>
        <div class="card">
            <div class="card-header">
                <?php echo $__env->make('commons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row align-content-between">
                    <div class="col-lg-4 col-md-4 col-sm-12 mt-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-tag"></i>
                                </span>
                            </div>
                            <select wire:model="categoria" class="form-control"  data-style="btn btn-link">
                                <option value="0">Todas la categorías</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if($productos->count()): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="bg-dark text-white">
                                <th width="50px">#</th>
                                <th>Categoría</th>
                                <th>Nombre</th>
                                <th class="text-center">Codigo</th>
                                <th class="text-right">Precio/U</th>
                                <th class="text-right">Precio/M</th>
                                <th class="text-center">Imagen</th>
                                <th class="text-right">Medida</th>
                                <th class="text-right">Stock</th>
                                <th class="text-right">Stock/M</th>
                                <th width="10px"></th>
                            </thead>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($producto->id); ?></td>
                                <td><?php echo e($producto->categoria->nombre); ?></td>
                                <td><?php echo e($producto->nombre); ?></td>
                                <td class="text-center"><?php echo QrCode::size(100)->generate($producto->codigo); ?></td>
                                <td class="text-right"><?php echo e($producto->precio_unitario); ?></td>
                                <td class="text-right"><?php echo e($producto->precio_por_mayor); ?></td>
                                <td class="text-center">
                                    <?php if($producto->image): ?>
                                    <img src="<?php echo e(asset('storage') . '/' . $producto->image); ?>" alt="" width="100" height="100">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('storage')); ?>/no-image.png" alt="" width="100" height="100">
                                    <?php endif; ?>
                                </td>
                                <td class="text-right"><?php echo e($producto->unidad_medida); ?></td>
                                <td class="text-right"><?php echo e($producto->stock); ?></td>
                                <td class="text-right"><?php echo e($producto->stock_minimo); ?></td>
                                <td>
                                    <?php if($producto->deleted_at): ?>
                                        <button class="btn btn-sm btn-secondary"><i class="fa fa-pen" disabled="disabled"></i></button>
                                        <button class="btn btn-sm btn-warning" wire:click="restore(<?php echo e($producto->id); ?>)"><i class="fa fa-sync"></i></button>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($producto->id); ?>)"><i class="fa fa-pen"></i></button>
                                        <button class="btn btn-sm btn-danger" wire:click="destroy(<?php echo e($producto->id); ?>)"><i class="fa fa-times-circle"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                <?php else: ?>
                    <h3>No se encontrarón resultados...</h3>
                <?php endif; ?>
            </div>
            <?php if($productos->count()): ?>
                <div class="card-footer">
                    <?php echo e($productos->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('livewire.productosForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.productosMedidaForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function(){
        window.livewire.on('show-modal', msg => {
            $('#theModal').modal('show');
        });

        window.livewire.on('message-show', msg => {
            $('#theModal').modal('hide');
            $('#theModalMedida').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 1500
            })
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/productos.blade.php ENDPATH**/ ?>