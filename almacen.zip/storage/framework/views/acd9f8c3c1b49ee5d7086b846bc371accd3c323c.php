<div class="card-body">
    <?php if($envios->count() > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-dark text-white">
                    <th width="50px">#</th>
                    <th>Usuario</th>
                    <th>Tienda</th>
                    <th width="200px">Estado</th>
                    <th width="200px">Fecha</th>
                    <th width="10px"></th>
                </thead>
                <?php $__currentLoopData = $envios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $envio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($envio->id); ?></td>
                    <td><?php echo e($envio->user->name); ?></td>
                    <td><?php echo e($envio->tienda->nombre); ?></td>
                    <td><?php echo e($envio->estado); ?></td>
                    <td><?php echo e($envio->created_at); ?></td>
                    <td>
                        <?php if($envio->estado == 'Completado'): ?>
                            <button class="btn btn-sm btn-success" wire:click="imprimirPDF(<?php echo e($envio->id); ?>)">
                                <span class="material-icons">
                                    print
                                </span>
                            </button>
                        <?php endif; ?>
                        <?php if($envio->estado == 'Cancelado'): ?>
                            <button class="btn btn-sm btn-danger">
                                <span class="material-icons">
                                    close
                                </span>
                            </button>
                        <?php endif; ?>
                        <?php if($envio->estado == 'Pendiente'): ?>
                            <button class="btn btn-sm btn-info" wire:click="verEnvio(<?php echo e($envio->id); ?>)">
                                <span class="material-icons">
                                    visibility
                                </span>
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php else: ?>
        <h3>No se encontraron resultados.</h3>
    <?php endif; ?>
</div>
<?php if($envios->count()): ?>
    <div class="card-footer">
        <?php echo e($envios->links()); ?>

    </div>
<?php endif; ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/enviosList.blade.php ENDPATH**/ ?>