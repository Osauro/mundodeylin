<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin')->html();
} elseif ($_instance->childHasBeenRendered('s3SJUbI')) {
    $componentId = $_instance->getRenderedChildComponentId('s3SJUbI');
    $componentTag = $_instance->getRenderedChildComponentTagName('s3SJUbI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s3SJUbI');
} else {
    $response = \Livewire\Livewire::mount('admin');
    $html = $response->html();
    $_instance->logRenderedChild('s3SJUbI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\almacen\resources\views/dashboard.blade.php ENDPATH**/ ?>