<?php echo $__env->make('commons.modalHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-12">
        <?php if(!is_null($producto)): ?>
        <div class="form-group mb-4">
            <label>Producto:</label>
            <p class="form-control"><?php echo e($producto->nombre); ?></p>
        </div>
        <?php endif; ?>
        <div class="form-group mb-4">
            <label>Cantidad:</label>
            <input type="number" wire:model.lazy="cantidad" class="form-control">
            <?php if(!is_null($producto)): ?>
                <small class="text-right">Máximo: <?php echo e($producto->stock); ?></small>
            <?php endif; ?>
            <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger er">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('commons.modalFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\laragon\www\almacen\resources\views/livewire/enviosForm.blade.php ENDPATH**/ ?>